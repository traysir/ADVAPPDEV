Start

Make coin dictionary with values

Take input sentence

Split input by "and"

For each item:
    Split it into number and coin
    Multiply number by coin value
    Add to total

Print total

End
